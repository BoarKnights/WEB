
# Create your models here.
from django.shortcuts import render
from pymongo import MongoClient
from django.db import models

#from django.utils import timezone

##class artsinfo(object):
    #def __init__(self):
        #self.client= MongoClient('localhost',27017)#10.120.28.86
   # def getOneartInfo(self):
        #db=self.client.photo
       # collection=db.autumn
       # artsInfoList=[]
        #for info in collection.find():
        #    artsInfoList.append(info)
       # return artsInfoList
       # client.close()

class searcharts(object):
	def __init__(self):
		self.client= MongoClient('10.120.28.86', 27017) #10.120.28.86

	def search(self,name):
		db=self.client.painting
		collection=db.wikiart
		artsList=[]
		#for post in collection.find({'title':{'$regex':name}},{'_id':0}):
		for post in collection.find({},{"resizepath":1,'_id':0}):
			post = post["resizepath"]
			artsList.append(post)

		return artsList # model to view
		client.close() 	

#class searchphoto(object):
	#def __init__(self):
		#self.client = MongoClient('10.120.28.86',27017)

	#def search(self,name):
		#db=self.client.photo
		#collection=db.autumn
		#photoList=[]
		#for post in collection.find({},{"resizepath":1,'_id':0}):
			#post = post["resizepath"]
			#photoList.append(post)
		#return photoList 
		#client.close()

class searchcolor(object):
	def __init__(self):
		self.client = MongoClient('10.120.28.86',27017)
	def search(self,cc):
		db=self.client.painting
		collection=db.wikiart
		paintingList=[]
		num = cc
		if num=="1" or num=="2" or num=="3" or num=="4" or num=="5" or num=="6" or num=="7" or num=="8" or num=="9":
			a="^{},".format(num)
			b=",{},".format(num)
			c=",{}$".format(num)
			
			for post in collection.find({"$or":[{"HSV":{"$regex":a}}, {"HSV":{"$regex":b}}, {"HSV":{"$regex":c}}]},{'_id':0}).sort('hsv_{}'.format(num), -1):
				c1 = float(post['co1_v'])
				c2 = float(post['co2_v'])
				c3 = float(post['co3_v'])
				c4 = float(post['co4_v'])
				c5 = 1-c1-c2-c3-c4
				
				c1 = str(c1*100) + '%'
				c2 = str(c2*100) + '%'
				c3 = str(c3*100) + '%'
				c4 = str(c4*100) + '%'
				c5 = str(c5*100) + '%'
				post = {'resizepath':post["resizepath"],'title':post["title"],'year':post["year"],'HSV':post["HSV"],'co1':post['co1'],'co1_v':c1,
							'co2':post['co2'],'co2_v':c2,'co3':post['co3'],'co3_v':c3,'co4':post['co4'],'co4_v':c4,'co5':post['co5'],'co5_v':c5
						}
				paintingList.append(post)
		else:
			for post in collection.find({'HSV':{'$regex':num}},{'_id':0}).sort('hsv_{}'.format(num), -1):
				if post['co1_v']=='' or post['co2_v']=='' or post['co3_v']=='' or post['co4_v']=='' or post['co5_v']=='':
					continue;
				c1 = float(post['co1_v'])
				c2 = float(post['co2_v'])
				c3 = float(post['co3_v'])
				c4 = float(post['co4_v'])
				c5 = 1-c1-c2-c3-c4
				
				c1 = str(c1*100) + '%'
				c2 = str(c2*100) + '%'
				c3 = str(c3*100) + '%'
				c4 = str(c4*100) + '%'
				c5 = str(c5*100) + '%'
				
				yyy = post["year"]
				post = {'resizepath':post["resizepath"],'title':post["title"],'year':post["year"],'HSV':post["HSV"],'co1':post['co1'],'co1_v':c1,
								'co2':post['co2'],'co2_v':c2,'co3':post['co3'],'co3_v':c3,'co4':post['co4'],'co4_v':c4,'co5':post['co5'],'co5_v':c5
						}
				paintingList.append(post)		
		return paintingList
		client.close()

class searchpainting(object):
	def __init__(self):
		self.client = MongoClient('10.120.28.86',27017)
	def search(self,name):
		db=self.client.painting
		collection=db.wikiart
		paintingList=[]
		return paintingList
		client.close()

class searchcontent(object):
	def __init__(self):
		self.client = MongoClient('10.120.28.86',27017)
	def search(self,ic):
		db=self.client.style
		collection=db.content
		imgcont = ic
		contentList=[]#portrait arch building round street shipwater stripe grid wilderness statue
		for post in collection.find({'content':{'$regex':imgcont}},{'_id':0}):
			#con = {'resizepath':con["resizepath"]}
			con = post["resizepath"]
			contentList.append(con)
		return contentList
		client.close()

class searchstyle(object):
	def __init__(self):
		self.client = MongoClient('10.120.28.86',27017)
	def search(self,imst):
		db=self.client.style
		collection=db.content
		imgstyle=imst
		styleList=[]
		for post in collection.find({'style':{'$regex':imgstyle}},{'_id':0}).sort("rank",1 ):
			post = post["resizepath"]
			styleList.append(post)
		return styleList
		client.close()


