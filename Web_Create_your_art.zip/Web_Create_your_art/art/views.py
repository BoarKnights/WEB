#coding=utf-8
from django.shortcuts import render
from django.http import HttpResponse  
from django.shortcuts import render_to_response

#from .models import artsinfo
from .models import searcharts
#from .models import searchphoto
from .models import searchpainting
from .models import searchcolor
from .models import searchstyle
from .models import searchcontent

# Create your views here.

#def post_list(request):
	#return render(request,'art/post_list.html',{}) #art/post_list.html

def index (request):
    return render(request,'art/frontpage.html')	
def photo (request):
    return render(request,'art/photo.html')	
def painting (request):
    return render(request,'art/painting.html')	

def getcolor(request,c_name):
    c_num = request.GET['hsv_color']
    arts = searchcolor().search(c_num)
    return render(request,'art/painting.html',locals())

def getcontent(request,img_content): # urls pass name to here
    img_content=request.GET['content'] 
    contents = searchcontent().search(img_content)
    return render_to_response('art/painting.html',locals())

def getstyle(request,img_style):
    img_style=request.GET['style']   	
    styles = searchstyle().search(img_style)
    return render(request,'art/painting.html',locals())


#def getarts(request,name):
	#name=request.GET['name']   #get name from html #一定要加['name']因為是要取GET物件的name屬性	
	#arts = searcharts().search(name)
	#return render_to_response('art/painting.html',locals())
#def get_hsv(request, value):#get value from html
	#v = request.GET['value']
	#return render(request,'art/painting.html',locals())


#def getpainting(request,name): # urls pass name to here

	#return render_to_response('art/painting.html',locals())


#def getphoto(request,name): # urls pass name to here
	#name=request.GET['name'] 
	#arts = searcharts().search(name)
	#return render_to_response('post_list.html',locals())


