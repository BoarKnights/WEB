from django.conf.urls import include, url
from django.contrib import admin

#from django.conf.urls import url
from . import views
#
urlpatterns=[
 #url(r'^$',views.post_list,name='post_list'),
  url(r'^$', views.index,name='index'),
  url(r'^photo/$',views.photo,name='photo'),
  url(r'^index/$',views.painting),
  url(r'^painting/$',views.painting),
  url(r'^(painting/color/$)',views.getcolor),
  url(r'^(painting/content/$)',views.getcontent),
  url(r'^(painting/style/$)',views.getstyle),

]
