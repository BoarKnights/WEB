$(document).ready(function(){
	var check = 0;
	$("#hsv").click(function(){
		if (check == 1){
			$("#hsvs").hide(1000);
			check = 0;
		}else{
			$("#hsvs").show(1000);
			check = 1;
		}
	});
});
$(document).ready(function(){
	var check = 0;
	$("#showcontent").click(function(){
		if (check == 1){
			$("#contents").hide(1000);
			check = 0;
		}else{
			$("#contents").show(1000);
			check = 1;
		}
	});
});
$(document).ready(function(){
	var check = 0;
	$("#showstyle").click(function(){
		if (check == 1){
			$("#styles").hide(1000);
			check = 0;
		}else{
			$("#styles").show(1000);
			check = 1;
		}
	});
});
