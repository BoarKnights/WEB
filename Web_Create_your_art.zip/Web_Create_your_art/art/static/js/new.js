$(function(){
  $("#photoZone").smoothDivScroll({
    autoScrollingMode: "always",    
    autoScrollingStep : 1
  });
});